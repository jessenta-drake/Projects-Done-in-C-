//#include <cstddef>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

/* The standard allocator interface from stdlib.h.  These are the
 * functions you must implement, more information on each function is
 * found below. They are declared here in case you want to use one
 * function in the implementation of another. */
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);

/* When requesting memory from the OS using sbrk(), request it in
 * increments of CHUNK_SIZE. */
#define CHUNK_SIZE (1<<12)

typedef struct FreeListBlock{
    size_t blocksize;
    struct FreeListBlock *next;
}FreeListBlock;

static FreeListBlock  **FreeTable;

//make an array and then loop through making everything null

/*
 * This function, defined in bulk.c, allocates a contiguous memory
 * region of at least size bytes.  It MAY NOT BE USED as the allocator
 * for pool-allocated regions.  Memory allocated using bulk_alloc()
 * must be freed by bulk_free().
 *
 * This function will return NULL on failure.
 */
extern void *bulk_alloc(size_t size);

/*
 * This function is also defined in bulk.c, and it frees an allocation
 * created with bulk_alloc().  Note that the pointer passed to this
 * function MUST have been returned by bulk_alloc(), and the size MUST
 * be the same as the size passed to bulk_alloc() when that memory was
 * allocated.  Any other usage is likely to fail, and may crash your
 * program.
 */
extern void bulk_free(void *ptr, size_t size);

/*
 * This function computes the log base 2 of the allocation block size
 * for a given allocation.  To find the allocation block size from the
 * result of this function, use 1 << block_size(x).
 *
 * Note that its results are NOT meaningful for any
 * size > 4088!
 *
 * You do NOT need to understand how this function works.  If you are
 * curious, see the gcc info page and search for __builtin_clz; it
 * basically counts the number of leading binary zeroes in the value
 * passed as its argument.
 */
static inline __attribute__((unused)) int block_index(size_t x) {
    if (x <= 8) {
        return 5;
    } else {
        return 32 - __builtin_clz((unsigned int)x + 7);
    }
}

/*
 * You must implement malloc().  Your implementation of malloc() must be
 * the multi-pool allocator described in the project handout.
 */
void *malloc(size_t size) {
    size_t myindex = block_index(size);
    void* chunky;
    /* void *givemem= sbrk(CHUNK_SIZE); */ 
    if (size == 0){
        return NULL;
    }
    if(size > (CHUNK_SIZE-sizeof(size_t))){
        void *storedsize = bulk_alloc(size+sizeof(size_t));
        *(size_t*)(storedsize)=size+sizeof(size_t);
        return((void *)storedsize)+sizeof(size_t);
    }
    
    if(FreeTable == NULL){
        FreeTable = sbrk(CHUNK_SIZE);
        for(int i=0; i < 13 ;i++) {
            FreeTable[i]= NULL;
            /* void *givemem= sbrk(CHUNK_SIZE); */
            /* FreeTable[myindex]=givemem; */
            /* for(int i =0; i <(CHUNK_SIZE/(1<<myindex)-1);i++){ */
            /*     ((FreeListBlock*)(givemem))->blocksize=1<<myindex; */
            /*     ((FreeListBlock*)(givemem))->next=givemem+(1<<myindex); */
            /*     givemem+=1<<myindex; */
            /* } */
            /* ((FreeListBlock*)(givemem))->blocksize = 1<<myindex; */
            /* ((FreeListBlock*)(givemem))->next= NULL; */
            /* int thesize =  block_index(size); */
            /* FreeListBlock *theoldhead = FreeTable[thesize]; */
            /* FreeTable[size]=theoldhead->next; */
            /* //return ((void *)theoldhead) + sizeof(size_t);  */
            /* return FreeTable[myindex]-sizeof(size_t); */

            // return givemem+sizeof(size_t);
        }
    }
    
    if(FreeTable[myindex]==NULL){
        //size_t myindex = block_index(size);  
        void *givemem= sbrk(CHUNK_SIZE);
        FreeTable[myindex]=(FreeListBlock*)givemem;
        for(int i =0; i <(CHUNK_SIZE/(1<<myindex)-1);i++){
            ((struct FreeListBlock*)(givemem))->blocksize=1<<myindex;
            ((struct FreeListBlock*)(givemem))->next=givemem+(1<<myindex);
            givemem+=(1<<myindex);
        }
        ((struct FreeListBlock*)(givemem))->blocksize = 1<<myindex;
        ((struct FreeListBlock*)(givemem))->next= NULL;
        /*  int thesize =  block_index(size); */
        /* FreeListBlock *theoldhead = FreeTable[thesize]; */
        /* FreeTable[size]=theoldhead->next; */
        /* //return ((void *)theoldhead) + sizeof(size_t);  */
        /* return FreeTable[myindex]+sizeof(size_t); */
    }
 
    if(FreeTable[myindex]!=NULL){
        int thesize =  block_index(size);
        FreeListBlock *theoldhead = FreeTable[thesize];
        FreeTable[thesize]=theoldhead->next;
        chunky = ((void *)theoldhead) + sizeof(size_t); 
    }
    /* printf("hello"); */
    return chunky;
    
    //return FreeTable[myindex]+sizeof(size_t);
}


\

/*
 * You must also implement calloc().  It should create allocations
 * compatible with those created by malloc().  In particular, any
 * allocations of a total size <= 4088 bytes must be pool allocated,
 * while larger allocations must use the bulk allocator.
 *
 * calloc() (see man 3 calloc) returns a cleared allocation large enough
 * to hold nmemb elements of size size.  It is cleared by setting every
 * byte of the allocation to 0.  You should use the function memset()
 * for this (see man 3 memset).
 */
void *calloc(size_t nmemb, size_t size) {
    if(nmemb ==0){
        return NULL;
    }

    if(size == 0){
        return NULL;
    }
    void *ptr = malloc(nmemb * size);
    memset(ptr, 0, nmemb * size);
    return ptr;
    /* size_t combine = nmemb*size; */
    /* if(combine > CHUNK_SIZE-8){ */
    /* void *ptr = bulk_alloc(nmemb * size); */
    /* memset(ptr, 0, nmemb * size); */
    /* return ptr; */
    /* } */
    /* else{ */
    /* void *nice = malloc(size); */
    /* memset(nice, 0, nmemb * size); */
    /* return nice; */
    /* } */
   
}

/*
 * You must also implement realloc().  It should create allocations
 * compatible with those created by malloc(), honoring the pool
 * alocation and bulk allocation rules.  It must move data from the
 * previously-allocated block to the newly-allocated block if it cannot
 * resize the given block directly.  See man 3 realloc for more
 * information on what this means.
 *
 * It is not possible to implement realloc() using bulk_alloc() without
 * additional metadata, so the given code is NOT a working
 * implementation!
 */
void *realloc(void *ptr, size_t size) {
    //fprintf(stderr, "Realloc is not implemented!\n");
    //size_t newSize =*(size_t*)(ptr-8);
    void*mysize;
    if(ptr==NULL){
        mysize =  malloc(size);
        return mysize;
    }
    if(size==0){
        return NULL;
    }
    
    /* if(newSize == size){ */
    /*     return ptr; */
    /* } */
    size_t newSize =*(size_t*)(ptr-sizeof(size_t)); 
    if(size<=newSize-sizeof(size_t)){
        return ptr;
    }
    else{
        mysize =  malloc(size);
       memcpy(mysize,ptr,newSize-sizeof(size_t));
       free(ptr);
       //return mysize;              
    }
    return mysize;
}

/*
 * You should implement a free() that can successfully free a region of
 * memory allocated by any of the above allocation routines, whether it
 * is a pool- or bulk-allocated region.
 *
 * The given implementation does nothing.
 */
void free(void *ptr) {
    if(ptr==NULL){
    return;
    }
    
    size_t newSize =*(size_t*)(ptr-sizeof(size_t));
    // size_t metasize = 8;
    
    /* if(newSize==0){ */
    /*     return; */
    /* } */
    ptr-=sizeof(size_t);
    if(newSize > CHUNK_SIZE){
        bulk_free(ptr,newSize);
        return;
    }
    else{
        int thesize =  block_index(newSize-sizeof(size_t));
       FreeListBlock *theoldhead = FreeTable[thesize];
       FreeTable[thesize] = (FreeListBlock*)ptr;
       FreeTable[thesize]-> next =theoldhead;
       return;
       // newone-> blocksize = 1<<thesize;
//(FreeListBlock*)(givemem)->next=givemem+(1<<myindex);
    
    }
    //return;
}
