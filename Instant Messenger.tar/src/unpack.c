
//#include <cstddef>
#include <stdlib.h>
#include <string.h>

#include "serialize.h"

/* Unpack the given packet into the buffer unpacked.  You can assume
 * that packed points to a packet buffer large enough to hold the
 * packet described therein, but you cannot assume that the packet is
 * otherwise valid.  You can assume that unpacked points to a character
 * buffer large enough to store the unpacked packet, if it is a valid
 * packet.
 *
 * Returns the packet type that was unpacked, or -1 if it is invalid.
 */
/// DO I NEED TO ADD A DELIMITER AFTER EACH ONE 
int unpack(char *unpacked, void *packed) {
   
    if( *(int*) packed == STATUS){
        packed += sizeof (int);
        for(int i =0; i< NAME_SIZE;i++ ){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
       
        size_t messageLength = *(size_t*)packed;
        packed += sizeof(size_t);
        packed += sizeof(size_t);
        // *unpacked = ':';
        // unpacked += sizeof(char);
        *unpacked = ' ';
        unpacked += sizeof(char);

        for(int i =0; i< messageLength;i++ ){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
        *unpacked = '\0';
        return STATUS;
    }
    if( *(int*) packed == LABELED){
        //moving size of the type 
        packed += sizeof (int);
        //packing my ubit
        for(int i =0; i< NAME_SIZE;i++){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
        //moving the size of all three lengths 
        size_t messageLength = *(size_t*)packed;
        packed += sizeof(size_t);
        size_t targetLength = *(size_t*)packed;
        packed += sizeof(size_t);
        packed += sizeof(size_t);

        //adding the : @
        *unpacked = ':';
        unpacked += sizeof(char);
        *unpacked = ' ';
        unpacked += sizeof(char);
        *unpacked = '@';
        unpacked += sizeof(char);

        //need to move size of the meesage
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        char savemymessage[messageLength];
        for(int i =0; i< messageLength;i++ ){
            if(*(char*) packed != '\0'){
                savemymessage[i] = *(char*)packed ;
                packed += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
        //unpacking the target
        for(int i =0; i<= targetLength;i++ ){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
        //unpacked += sizeof(char);
         *unpacked = ' ';
         unpacked += sizeof(char);
        // *unpacked = ' ';
        //unpacking the message
        // memset(unpacked,'\0',messageLength+1); 
        memcpy(unpacked,savemymessage,messageLength+1); 
        /* for(int i =0; i< messageLength;i++ ){ */
        /*     if(*(char*) packed != '\0'){ */
        /*         *unpacked =*(char*)packed ; */
        /*         packed += sizeof(char); */
        /*         unpacked += sizeof(char); */
        /*     } */
        /*     else{ */
        /*         packed += sizeof(char); */
        /*     } */
        /* } */
        unpacked += messageLength;
        *unpacked = '\0';
        return LABELED;
    }
    if( *(int*) packed == MESSAGE){
        packed += sizeof (int);
        for(int i =0; i< NAME_SIZE;i++ ){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
       
        size_t messageLength = *(size_t*)packed;
        packed += sizeof(size_t);
        packed += sizeof(size_t);
        *unpacked = ':';
        unpacked += sizeof(char);
        *unpacked = ' ';
        unpacked += sizeof(char);

        for(int i =0; i< messageLength;i++ ){
            if(*(char*) packed != '\0'){
                *unpacked =*(char*)packed ;
                packed += sizeof(char);
                unpacked += sizeof(char);
            }
            else{
                packed += sizeof(char);
            }
        }
        *unpacked = '\0';
        return MESSAGE;
    }
    
    return -1;
     
}

/* Unpack the given packed packet into the given statistics structure.
 * You can assume that packed points to a packet buffer large enough to
 * hold the statistics packet, but you cannot assume that it is
 * otherwise valid.  You can assume that statistics points to a
 * statistics structure.
 *
 * Returns the packet type that was unpacked, or -1 if it is invalid.
 */
int unpack_statistics(struct statistics *statistics, void *packed) {
    if( *(int*) packed == STATISTICS){
        packed+=sizeof(int);
        strncpy(statistics->sender,packed,NAME_SIZE);
        statistics->sender[NAME_SIZE]='\0';
        packed+=NAME_SIZE;
        strncpy(statistics->most_active,packed,NAME_SIZE);
        statistics->most_active[NAME_SIZE]='\0';
        packed+=NAME_SIZE;
        statistics->most_active_count=*(int*)packed;
        packed+=sizeof(int);
        statistics->invalid_count=*(long*)packed;
        packed+=sizeof(long);
        statistics->refresh_count=*(long*)packed;
        packed+=sizeof(long);
        statistics->messages_count=*(int*)packed;
        packed+=sizeof(int);
        return STATISTICS;
    }
    return -1;
}
