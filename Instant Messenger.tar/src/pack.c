#include <stdlib.h>
#include <string.h>

#include "serialize.h"

/* Pack the user input provided in input into the appropriate message
 * type in the space provided by packed.  You can assume that input is a
 * NUL-terminated string, and that packed is a buffer of size
 * PACKET_SIZE.
 *
 * Returns the packet type for valid input, or -1 for invalid input.
 */
int pack(void *packed, char *input) {
    int spacecounter =0;
    int countspaces = 0;
    int spacesbetween =0;
    if(strncmp(input,"/me ",4)==0){
        *(int*)packed=STATUS;
        packed += sizeof(int);
        char myubit[8] = "jessenta";
        memset(packed,'\0',NAME_SIZE);
        memcpy(packed,myubit,strlen(myubit));
        packed +=NAME_SIZE;
        for(int i=4 ; i != '\0';i++){
            if(input[i]==' '){
                spacecounter++;
            }
            else{
                break;
            }
        }
        spacecounter+=4;
        size_t theValue = strlen(input)-spacecounter;
        if(theValue==0){//comparing size t and int, might not work 
            return -1;
        }
        if(theValue> MAX_MESSAGE_SIZE)
            {
                return -1;
            }
        *(size_t*)packed=theValue;
        packed += sizeof(size_t);
        
        *(size_t*)packed=0;
        packed += sizeof(size_t);
        //good here
        
        
        for(int i=spacecounter ; input[i]!='\0' ;i++){
            *(char*) packed = input[i];
            packed += sizeof (char);
            // myMessage[i]=input[i];
        }
        // packed+=sizeof(char)*theValue;
        return STATUS;
    }
    else if(strncmp(input, "@",1)==0){// check 
        //packing the type 
        *(int*)packed=LABELED;
        packed += sizeof(int);
        //packing my ubit
        char myubit3[8] = "jessenta";
        memset(packed,'\0',NAME_SIZE);
        memcpy(packed,myubit3,strlen(myubit3));
        packed +=NAME_SIZE;
        //counting the spaces after the ubit
        for(int i=1 ; input[i] != '\0';i ++){
            if(input[i]==' '){
                spacesbetween++;
            }
            else{
                break;
            }
        }
        //counting the letters of the ubit after the @
        for(int i=0 ; input[i] != '\0';i ++){
            if(input[i]!=' '){
                spacecounter++;
            }
            else{
                break;
            }
        }
        //storing the message length and handling edge casess
        size_t theValue = strlen(input)-(spacecounter+spacesbetween+1);
        if(theValue==0){//comparing size t and int, might not work 
            return -1;
        }
        if(theValue> MAX_MESSAGE_SIZE)
            {
                return -1;
            }
        //storing the target length and handling edge cases
        size_t thetargetlen = spacecounter-1;
        if(thetargetlen >16){
            return -1;
        }

        if(thetargetlen<=0){
            return -1;
        }
        //packing all the lengths
        *(size_t*)packed=theValue;
        packed += sizeof(size_t);
        *(size_t*)packed=thetargetlen;
        packed += sizeof(size_t);
        *(size_t*)packed=0;
        packed += sizeof(size_t);

        //packing the message 
        for(int i=spacecounter+spacesbetween+1;input[i] != '\0';i++){
            *(char*) packed = input[i];
            packed += sizeof (char);
        }
        //packing the target 
        for(int i=1; input[i] != ' ';i++){
            *(char*) packed = input[i];
            packed += sizeof(char);
        }
        return LABELED;
    }
   
    else if(strncmp (input, "/stats",6)==0){
        *(int*)packed=STATISTICS;
        packed += sizeof(int);
        char myubit[8] = "jessenta";
        memset(packed,'\0',NAME_SIZE);
        memcpy(packed,myubit,strlen(myubit));
        packed +=sizeof(NAME_SIZE);
        return STATISTICS;
           
    } 
    else{
        for(int i = 0;i < strlen(input);i++){
            if(input[i] == ' '){
                countspaces++;
            }
        }
        if(countspaces == strlen(input)){
            return -1;
        }
        else if(countspaces < strlen(input)){
            *(int*)packed=MESSAGE;
            packed += sizeof(int);
            char myubit2[8] = "jessenta";
            memset(packed,'\0',NAME_SIZE);
            memcpy(packed,myubit2,strlen(myubit2));
            packed +=NAME_SIZE;
            size_t theValue = strlen(input);
            if(theValue==0){//comparing size t and int, might not work 
                return -1;
            }
            if(theValue> MAX_MESSAGE_SIZE)
                {
                    return -1;
                }
            *(size_t*)packed=theValue;
            packed += sizeof(size_t);
            *(size_t*)packed=0;
            packed += sizeof(size_t);
            for(int i=spacecounter ; input[i] != '\0';i++){
                *(char*) packed = input[i];
                packed += sizeof (char);
            } 
        
            return MESSAGE;
        }
    }
    return -1;
}

/* Create a refresh packet for the given message ID.  You can assume
 * that packed is a buffer of size PACKET_SIZE.
 *
 * You should start by implementing this method!
 *
 * Returns the packet type.
 */
int pack_refresh(void *packed, int message_id) {
    //storing the type 
    *(int*)packed=REFRESH;
    // moving to the next spot 
    packed+=sizeof(int);
    // initializing my ubit
    char myubit[8]="jessenta";
    //filling up with delimiter
    memset(packed,'\0',NAME_SIZE);
    //copying and storing my ubit into the space
    memcpy(packed,myubit,8);
    //moving again
    packed +=(NAME_SIZE);
    //storing the id to the last message
    *(int*)packed=message_id;
    packed+=sizeof(int);
    return REFRESH;
}
