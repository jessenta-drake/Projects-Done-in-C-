#include <pthread.h>
#include <stdlib.h>

#include "csesem.h"
#include "pcq.h"

/* This structure must contain everything you need for an instance of a
 * PCQueue.  The given definition is ABSOLUTELY NOT COMPLETE.  You will
 * have to add several items to this structure. */
struct PCQueue {
    int slots;
    void **queue;
    int front; /* buf[(front+1)%n] is first item */
    int rear; /* buf[rear%n] is last item */
    pthread_mutex_t mutex; /* Protects accesses to buf */
    CSE_Semaphore availslots; /* Counts available slots */
    CSE_Semaphore items; /* Counts available items */
};

/* The given implementation performs no error checking and simply
 * allocates the queue itself.  You will have to create and initialize
 * (appropriately) semaphores, mutexes, condition variables, flags,
 * etc. in this function. */
PCQueue pcq_create(int slots) {
    if(slots <= 0){
        return NULL;
    }
    PCQueue pcq;

    pcq = calloc(1, sizeof(*pcq));
    pcq->queue = calloc(slots, sizeof(void *));
    pcq->slots = slots;

    pcq->front = pcq->rear = 0; /* Empty buffer iff front == rear */
    pthread_mutex_init(&pcq->mutex,NULL); /* Binary semaphore for locking */
    pcq->availslots = csesem_create(slots); /* Initially, buf has n empty slots */
    pcq-> items =csesem_create(0); /* Initially, buf has zero data items */

    return pcq;
}

/* This implementation does nothing, as there is not enough information
 * in the given struct PCQueue to even usefully insert a pointer into
 * the data structure. */
void pcq_insert(PCQueue pcq, void *data) {
    
    csesem_wait(pcq->availslots); /* Wait for available slot */
    pthread_mutex_lock(&pcq->mutex); /* Lock the buffer */
    pcq->queue[(++pcq->rear)%(pcq->slots)] = data; /* Insert the item */
    pthread_mutex_unlock(&pcq->mutex); /* Unlock the buffer */
    csesem_post(pcq->items); /* Announce available item */
}

/* This implementation does nothing, for the same reason as
 * pcq_insert(). */
void *pcq_retrieve(PCQueue pcq) {
    if( pcq == NULL){
        return NULL;
    }
    void* item;
    csesem_wait(pcq->items); /* Wait for available item */
    pthread_mutex_lock(&pcq->mutex); /* Lock the buffer */
    item = pcq->queue[(++pcq->front)%(pcq->slots)]; /* Remove the item */
    pthread_mutex_unlock(&pcq->mutex); /* Unlock the buffer */
    csesem_post(pcq->availslots); /* Announce available slot */
    return item;
    
    //return NULL;
}

/* The given implementation blindly frees the queue.  A minimal
 * implementation of this will need to work harder, and ensure that any
 * synchronization primitives allocated here are destroyed; a complete
 * and correct implementation will have to synchronize with any threads
 * blocked in pcq_insert() or pcq_retrieve().
 *
 * You should implement the complete and correct clean teardown LAST.
 * Make sure your other operations work, first, as they will be tightly
 * intertwined with teardown and you don't want to be debugging it all
 * at once!
 */
void pcq_destroy(PCQueue pcq) {
    free(pcq->queue);
    free(pcq);
}
